
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable{
	IntWritable val;
	
	public MyValue(){
		this.val = new IntWritable();
	}
	public MyValue(IntWritable line){
		this.val =line;
	};
	
	@Override
	public void readFields(DataInput arg0) throws IOException {
		val.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		val.write(arg0);
	}
	
	public void setLine(IntWritable line){
		this.val=line;
	}
	public IntWritable getLine(){
		return val;
	}

}
