

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<myKey, MyValue, Text, IntWritable> {
	
	public void map(myKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		String gen = inpV.toString();
	    String gen1[]=gen.split(",");
	    Text a= inpK.getGen();
	    IntWritable b= inpV.getLine();
	    c.write(new Text(a.toString()), new IntWritable(1));	
	    	}
	    }

	    
			
		

